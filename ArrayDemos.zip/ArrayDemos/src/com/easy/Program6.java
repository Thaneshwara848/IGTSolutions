package com.easy;

import java.util.Arrays;

public class Program6 {

    public static void main(String[] args) {
        // Original array
        int[] originalArray = {1, 2, 3, 4, 5};

        // Create a new array with the same length as the original array
        int[] copiedArray = new int[originalArray.length];

        // Copy elements from the original array to the new array
        for (int i = 0; i < originalArray.length; i++) {
            copiedArray[i] = originalArray[i];
        }

        // Print both arrays
        System.out.println("Original Array: " + Arrays.toString(originalArray));
        System.out.println("Copied Array: " + Arrays.toString(copiedArray));
    }
}
