package com.easy;

public class Program18 {
    public static void main(String[] args) {
        // Sample array
        int[] array = {5, 2, 8, 3, 6};

        // Call the method to find the cumulative sum
        findCumulativeSum(array);
    }

    public static void findCumulativeSum(int[] array) {
        int cumulativeSum = 0;

        System.out.println("Cumulative sum of elements:");
        for (int num : array) {
            cumulativeSum += num;  // Add current element to cumulative sum
            System.out.println(cumulativeSum);  // Print the cumulative sum at each step
        }
    }
}
