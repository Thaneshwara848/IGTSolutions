package com.easy;

public class Program13 {
    public static void main(String[] args) {
        // Sample array
        int[] array = {5, 2, 8, 3, 6, 7, 10};

        // Call the method to print odd numbers
        printOddNumbers(array);
    }

    public static void printOddNumbers(int[] array) {
        System.out.println("Odd numbers in the array:");
        for (int num : array) {
            if (num % 2 != 0) {  // Check if the number is odd
                System.out.println(num);
            }
        }
    }
}
