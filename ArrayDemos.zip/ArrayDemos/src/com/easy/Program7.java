package com.easy;

import java.util.Arrays;

public class Program7 {
    public static void main(String[] args) {
        // Sample array
        int[] array = {5, 2, 8, 1, 3};

        // Sorting the array in ascending order
        Arrays.sort(array);

        // Printing the sorted array
        System.out.println("Sorted array: " + Arrays.toString(array));
    }
}
class Program71
{
		void withoutusingSortmethod() {
			   // Sample array
	        int[] array = {5, 2, 8, 1, 3};

	        // Bubble Sort to arrange the array in ascending order
	        for (int i = 0; i < array.length - 1; i++) {
	            for (int j = 0; j < array.length - 1 - i; j++) {
	                // Swap if the current element is greater than the next element
	                if (array[j] > array[j + 1]) {
	                    int temp = array[j];
	                    array[j] = array[j + 1];
	                    array[j + 1] = temp;
	                }
	            }
	        }

	        // Printing the sorted array
	        System.out.print("Sorted array: ");
	        for (int num : array) {
	            System.out.print(num + " ");
	        }
	    }
	
}
